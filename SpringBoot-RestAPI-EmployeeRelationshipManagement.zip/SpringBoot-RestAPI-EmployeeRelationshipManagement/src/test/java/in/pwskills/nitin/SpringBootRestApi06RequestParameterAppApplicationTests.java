package in.pwskills.nitin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestApi06RequestParameterAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
