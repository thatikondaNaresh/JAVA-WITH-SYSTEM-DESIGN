package in.pwskills.nitin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestApi06RequestParameterAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApi06RequestParameterAppApplication.class, args);
	}

}
