package in.pwskills.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Employee {
	
	@Value("7")
	private Integer empId;
	
	@Value("dhoni")
	private String empName;
	
	@Value("CSK")
	private String empAdress;
	
	@Value("3500.0")
	private Double empSalary;
	
	static {
		System.out.println("EMPLOYEE.CLASS FILE IS LOADING...");
	}

	public Employee() {
		System.out.println("EMPLOYEE OBJECT CREATED BY FRAMEWORK...");
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empAdress=" + empAdress + ", empSalary="
				+ empSalary + "]";
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAdress() {
		return empAdress;
	}

	public void setEmpAdress(String empAdress) {
		this.empAdress = empAdress;
	}

	public Double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(Double empSalary) {
		this.empSalary = empSalary;
	}

}
