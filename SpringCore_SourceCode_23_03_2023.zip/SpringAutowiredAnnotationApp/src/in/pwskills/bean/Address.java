package in.pwskills.bean;

import org.springframework.beans.factory.annotation.Value;


public class Address {

	@Value("IND")
	private String country;

	@Value("MAHARASHTRA")
	private String state;

	@Value("560035")
	private Integer pinCode;

	@Override
	public String toString() {
		return "Address [country=" + country + ", state=" + state + ", pinCode=" + pinCode + "]";
	}

}
