package in.pwskills.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Employee {

	@Value("7")
	private Integer empId;

	@Value("dhoni")
	private String empName;

	@Value("3500.0")
	private Double empSalary;

	@Autowired(required = false) //Linking 2 objects using HAS-A relationship
	private Address address;

	static {
		System.out.println("EMPLOYEE.CLASS FILE IS LOADING...");
	}

	public Employee() {
		System.out.println("EMPLOYEE OBJECT CREATED BY FRAMEWORK...");
	}

	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", address=" + address
				+ "]";
	}


	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(Double empSalary) {
		this.empSalary = empSalary;
	}

}
