package in.pwskills.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import in.pwskills.bean.Product;
import in.pwskills.config.AppConfig;

public class Test {

	public static void main(String[] args) {

		// Starting the container and informing the configuration file to scan for spring-bean
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);

		Product product = applicationContext.getBean(Product.class);
		System.out.println(product);

		// closing the container
		((AbstractApplicationContext) applicationContext).close();

	}
}
