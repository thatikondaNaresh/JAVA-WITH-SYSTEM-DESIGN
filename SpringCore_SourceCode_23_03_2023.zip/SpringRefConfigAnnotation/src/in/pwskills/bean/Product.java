package in.pwskills.bean;

//Target Object
public class Product {

	private Integer pid;
	private String pname;
	private Double pcost;

	//HAS-A relationship
	private Model model;

	public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
		System.out.println("Product.setModel()");
	}

	static {
		System.out.println("PRODUCT.CLASS FILE IS LOADING...");
	}

	public Product() {
		System.out.println("PRODUCT OBJECT CREATED BY FRAMEWORK...");
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
		System.out.println("Product.setPid()");
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
		System.out.println("Product.setPname()");
	}

	public Double getPcost() {
		return pcost;
	}

	public void setPcost(Double pcost) {
		this.pcost = pcost;
		System.out.println("Product.setPcost()");
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", pcost=" + pcost + ", model=" + model + "]";
	}
}
