package in.pwskills.bean;

//Dependent object
public class Model {

	private Integer mid;
	private String mtype;

	static {
		System.out.println("\nMODEL.CLASS FILE IS LOADING...");
	}

	public Model() {
		System.out.println("Model OBJECT CREATED BY FRAMEWORK...");
	}

	public Integer getMid() {
		return mid;
	}

	public void setMid(Integer mid) {
		this.mid = mid;
		System.out.println("Model.setMid()");
	}

	public String getMtype() {
		return mtype;
	}

	public void setMtype(String mtype) {
		this.mtype = mtype;
		System.out.println("Model.setMtype()");
	}

	@Override
	public String toString() {
		return "Model [mid=" + mid + ", mtype=" + mtype + "]";
	}

}
