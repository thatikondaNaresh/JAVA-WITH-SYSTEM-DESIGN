package in.pwskills.bean;

import org.springframework.stereotype.Component;

@Component("dtdc")
public class DTDC implements Courier {

	@Override
	public String deliver(Integer otp) {
		return "Delivering " + otp + " Order ID purchased using DTDC...";
	}

	static {
		System.out.println("DTDC.CLASS FILE IS LOADING...");
	}

	public DTDC() {
		System.out.println("DTDC :: OBJECT CREATED...");
	}

	@Override
	public String toString() {
		return "DTDC []";
	}

}
