package in.pwskills.bean;

import org.springframework.stereotype.Component;

@Component("bdart")
public class BlueDart implements Courier {

	@Override
	public String deliver(Integer otp) {
		return "Delivering "+otp+" Order ID purchased using BLUEDART...";
	}

	static {
		System.out.println("BLUEDART.CLASS FILE IS LOADING...");
	}

	public BlueDart() {
		System.out.println("BLUEDART :: OBJECT CREATED...");
	}

	@Override
	public String toString() {
		return "BlueDart []";
	}

}
