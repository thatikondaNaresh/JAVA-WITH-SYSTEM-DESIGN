package in.pwskills.bean;

public interface Courier {
	public String deliver(Integer otp);
}
