package in.pwskills.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import in.pwskills.bean.Flipkart;
import in.pwskills.config.AppConfig;

public class Test {

	public static void main(String[] args) {

		// Starting the container and informing the configuration file to scan for
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);

		Flipkart flipkart = applicationContext.getBean(Flipkart.class);
		System.out.println(flipkart);

		String status = flipkart.shopping(new String[] { "fossil", "CalvinKlen", "Puma" },
				new float[] { 34556.0f, 25000.0f, 15000.0f });
		System.out.println(status);

		// closing the container
		((AbstractApplicationContext) applicationContext).close();

	}
}
