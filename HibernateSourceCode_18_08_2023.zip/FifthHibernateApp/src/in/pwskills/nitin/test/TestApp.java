package in.pwskills.nitin.test;

import java.io.IOException;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.pwskills.nitin.entity.Student;

public class TestApp {
	public static void main(String[] args) throws IOException {

		SessionFactory sessionFactory = new Configuration().configure().addAnnotatedClass(Student.class)
				.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();

		// insert operation
		Student student = new Student();
		student.setSid(10);
		student.setSname("sachin");
		student.setDt1(new Date());
		student.setDt2(new Date());
		student.setDt3(new Date());

		session.save(student);

		transaction.commit();
		
		
		session.close();
		System.out.println("Application is stopping....");
	}
}
