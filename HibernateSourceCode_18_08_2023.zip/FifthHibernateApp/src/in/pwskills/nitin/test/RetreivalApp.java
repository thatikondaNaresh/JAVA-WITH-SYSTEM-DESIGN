package in.pwskills.nitin.test;

import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.pwskills.nitin.entity.Student;

public class RetreivalApp {
	public static void main(String[] args) throws IOException {

		SessionFactory sessionFactory = new Configuration().configure().addAnnotatedClass(Student.class)
				.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		int id = 10;
		Student student = session.get(Student.class, id);
		if (student != null) {
			System.out.println(student);			
		}else {
			System.out.println("Record not available for the given id :: "+id);
		}
		
		
		session.close();
		System.out.println("Application is stopping....");
	}
}
