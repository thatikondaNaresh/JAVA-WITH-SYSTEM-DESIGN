package in.pwskills.nitin.test;

import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.pwskills.nitin.entity.Employee;

public class TestApp {

	public static void main(String[] args) throws IOException {

		Configuration configuration = new Configuration();
		configuration.configure();
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Integer id = 7;
		Employee employee = session.get(Employee.class, id);

		if (employee != null) {
			Transaction transaction = session.beginTransaction();
			session.delete(employee);
			transaction.commit();
		} else {
			System.out.println("Record not available for the given id :: " + id);
		}

		session.close();

	}
}
