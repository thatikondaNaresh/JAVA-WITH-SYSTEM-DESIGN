package in.pwskills.nitin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="EMPLOYEE")
public class Employee {
	
	@Id
	@Column(name="EID")
	private Integer eid;
	
	@Column(name="ENAME")
	private String ename;
	
	@Column(name="EAGE")
	private Integer eage;
	
	@Column(name="EADDRESS")
	private String eadress;
	
	public Employee() {
		System.out.println("USED BY HIBERNATE INTERNALLY :: " +this);
	}

	public Integer getEid() {
		return eid;
	}

	public void setEid(Integer eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public Integer getEage() {
		return eage;
	}

	public void setEage(Integer eage) {
		this.eage = eage;
	}

	public String getEadress() {
		return eadress;
	}

	public void setEadress(String eadress) {
		this.eadress = eadress;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", eage=" + eage + ", eadress=" + eadress + "]";
	}

}
