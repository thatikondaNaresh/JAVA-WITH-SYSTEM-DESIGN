package in.pwskills.nitin.test;

import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import in.pwskills.nitin.entity.Employee;

public class TestApp {

	public static void main(String[] args) throws IOException {

		Configuration configuration = new Configuration();

		configuration.configure();

		SessionFactory sessionFactory = configuration.buildSessionFactory();

		Session session = sessionFactory.openSession();

		Employee employee = session.get(Employee.class, 7);
		System.out.println("EID IS      :: " + employee.getEid());
		System.out.println("ENAME IS    :: " + employee.getEname());
		System.out.println("EAGE  IS    :: " + employee.getEage());
		System.out.println("EADDRESS IS :: " + employee.getEadress());

		System.in.read();

		System.out.println();
		
		Employee employee1 = session.get(Employee.class, 7);
		System.out.println("EID IS      :: " + employee1.getEid());
		System.out.println("ENAME IS    :: " + employee1.getEname());
		System.out.println("EAGE  IS    :: " + employee1.getEage());
		System.out.println("EADDRESS IS :: " + employee1.getEadress());

		session.close();

	}
}
